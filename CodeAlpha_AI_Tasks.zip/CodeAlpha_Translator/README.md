# CodeAlpha_LanguageTranslationTool
Flask web app that translates text between languages using Google Translate (via `deep-translator`).
Features: source/target language selection, auto-detect, swap, copy button, text-to-speech.

## Run
pip install -r requirements.txt
python app.py   # open http://127.0.0.1:5000
