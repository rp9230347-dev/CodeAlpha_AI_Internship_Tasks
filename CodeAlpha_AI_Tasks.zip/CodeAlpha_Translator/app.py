from flask import Flask, render_template_string, request, jsonify
from deep_translator import GoogleTranslator

app = Flask(__name__)
LANGS = GoogleTranslator().get_supported_languages(as_dict=True)  # {'hindi': 'hi', ...}

PAGE = """<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Language Translation Tool</title>
<style>
 body{font-family:Segoe UI,Arial,sans-serif;background:#f4f6fb;margin:0;padding:20px}
 .box{max-width:720px;margin:auto;background:#fff;padding:24px;border-radius:14px;box-shadow:0 4px 18px #0001}
 h1{margin-top:0;font-size:1.5rem}
 .row{display:flex;gap:10px;margin-bottom:12px}
 select,textarea,button{font-size:1rem;padding:10px;border-radius:8px;border:1px solid #ccd}
 select{flex:1} textarea{width:100%;box-sizing:border-box;height:130px;resize:vertical}
 button{background:#3b5bdb;color:#fff;border:none;cursor:pointer}
 button.alt{background:#e7ebff;color:#233}
 #out{background:#f1f3ff;min-height:80px;padding:12px;border-radius:8px;margin-top:12px;white-space:pre-wrap}
</style></head><body><div class="box">
<h1>🌐 Language Translation Tool</h1>
<div class="row">
 <select id="src"><option value="auto">Auto-detect</option>
 {% for name, code in langs.items() %}<option value="{{code}}">{{name.title()}}</option>{% endfor %}</select>
 <button class="alt" onclick="swap()">⇄</button>
 <select id="tgt">{% for name, code in langs.items() %}
 <option value="{{code}}" {{'selected' if code=='hi' else ''}}>{{name.title()}}</option>{% endfor %}</select>
</div>
<textarea id="text" placeholder="Enter text here..."></textarea>
<div class="row" style="margin-top:10px"><button onclick="translate()">Translate</button></div>
<div id="out">Translation will appear here</div>
<div class="row" style="margin-top:10px">
 <button class="alt" onclick="copyText()">📋 Copy</button>
 <button class="alt" onclick="speak()">🔊 Speak</button>
</div></div>
<script>
async function translate(){
 const text=document.getElementById('text').value.trim();
 if(!text){return}
 const out=document.getElementById('out'); out.textContent='Translating...';
 const r=await fetch('/translate',{method:'POST',headers:{'Content-Type':'application/json'},
  body:JSON.stringify({text,source:src.value,target:tgt.value})});
 const d=await r.json(); out.textContent=d.translated||('Error: '+d.error);
}
function swap(){ if(src.value==='auto')return; const t=src.value; src.value=tgt.value; tgt.value=t; }
function copyText(){ navigator.clipboard.writeText(document.getElementById('out').textContent); }
function speak(){ const u=new SpeechSynthesisUtterance(document.getElementById('out').textContent);
 u.lang=tgt.value; speechSynthesis.speak(u); }
</script></body></html>"""

@app.route("/")
def index():
    return render_template_string(PAGE, langs=LANGS)

@app.route("/translate", methods=["POST"])
def translate():
    data = request.get_json()
    try:
        result = GoogleTranslator(source=data["source"], target=data["target"]).translate(data["text"])
        return jsonify(translated=result)
    except Exception as e:
        return jsonify(error=str(e)), 400

if __name__ == "__main__":
    app.run(debug=True)
