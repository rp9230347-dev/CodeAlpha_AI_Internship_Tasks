"""Object Detection & Tracking: YOLOv8 (detection) + Deep SORT (tracking) with OpenCV.
Usage:
  python main.py              # webcam
  python main.py video.mp4    # video file
Press 'q' to quit.
"""
import sys
import cv2
from ultralytics import YOLO
from deep_sort_realtime.deepsort_tracker import DeepSort

source = sys.argv[1] if len(sys.argv) > 1 else 0
model = YOLO("yolov8n.pt")            # pre-trained on COCO (auto-downloads)
tracker = DeepSort(max_age=30)
cap = cv2.VideoCapture(source)

while cap.isOpened():
    ok, frame = cap.read()
    if not ok:
        break

    # 1) Detect objects in the frame
    result = model(frame, verbose=False)[0]
    detections = []
    for box in result.boxes:
        conf = float(box.conf[0])
        if conf < 0.4:
            continue
        x1, y1, x2, y2 = map(int, box.xyxy[0])
        cls_name = model.names[int(box.cls[0])]
        detections.append(([x1, y1, x2 - x1, y2 - y1], conf, cls_name))

    # 2) Track them with Deep SORT
    for t in tracker.update_tracks(detections, frame=frame):
        if not t.is_confirmed():
            continue
        x1, y1, x2, y2 = map(int, t.to_ltrb())
        label = f"{t.det_class} ID:{t.track_id}"
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 200, 0), 2)
        cv2.putText(frame, label, (x1, max(y1 - 8, 15)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 200, 0), 2)

    cv2.imshow("Object Detection & Tracking", frame)
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
