# CodeAlpha_ObjectDetectionTracking
Real-time object detection (YOLOv8) + tracking (Deep SORT) using OpenCV. Shows labels and tracking IDs.

## Run
pip install -r requirements.txt
python main.py            # webcam
python main.py video.mp4  # video file
