# Simple chat UI: python app.py -> http://127.0.0.1:5000
from flask import Flask, request, jsonify, render_template_string
from chatbot import FAQBot

app = Flask(__name__)
bot = FAQBot()

PAGE = """<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>FAQ Chatbot</title><style>
body{font-family:Segoe UI,Arial;background:#f4f6fb;margin:0;padding:16px}
.box{max-width:600px;margin:auto;background:#fff;border-radius:14px;padding:16px;box-shadow:0 4px 18px #0001}
#chat{height:380px;overflow:auto;padding:8px}
.m{margin:8px 0;padding:10px 14px;border-radius:12px;max-width:80%}
.u{background:#3b5bdb;color:#fff;margin-left:auto}.b{background:#eef0ff}
input{width:75%;padding:10px;border-radius:8px;border:1px solid #ccd}button{padding:10px 16px;border:0;border-radius:8px;background:#3b5bdb;color:#fff}
</style></head><body><div class="box"><h2>🤖 FAQ Chatbot</h2><div id="chat"></div>
<input id="q" placeholder="Ask a question..." onkeydown="if(event.key==='Enter')send()"><button onclick="send()">Send</button></div>
<script>
function add(t,c){const d=document.createElement('div');d.className='m '+c;d.textContent=t;chat.appendChild(d);chat.scrollTop=chat.scrollHeight}
async function send(){const t=q.value.trim();if(!t)return;add(t,'u');q.value='';
const r=await fetch('/ask',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({q:t})});
add((await r.json()).answer,'b')}
add('Hi! Ask me anything about Python.','b')
</script></body></html>"""

@app.route("/")
def home(): return render_template_string(PAGE)

@app.route("/ask", methods=["POST"])
def ask(): return jsonify(answer=bot.reply(request.get_json()["q"]))

if __name__ == "__main__":
    app.run(debug=True)
