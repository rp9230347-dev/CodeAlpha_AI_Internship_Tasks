# CodeAlpha_FAQ_Chatbot
FAQ chatbot using NLTK preprocessing (tokenize, stopword removal, lemmatize) + TF-IDF & cosine similarity.

## Run
pip install -r requirements.txt
python chatbot.py   # terminal chat
python app.py       # web chat UI at http://127.0.0.1:5000
