import json, string
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

for pkg in ["punkt", "punkt_tab", "stopwords", "wordnet"]:
    nltk.download(pkg, quiet=True)

STOP = set(stopwords.words("english"))
LEM = WordNetLemmatizer()

def preprocess(text: str) -> str:
    tokens = word_tokenize(text.lower())
    tokens = [LEM.lemmatize(t) for t in tokens if t not in string.punctuation and t not in STOP]
    return " ".join(tokens)

class FAQBot:
    def __init__(self, path="faqs.json", threshold=0.25):
        self.faqs = json.load(open(path, encoding="utf-8"))
        self.threshold = threshold
        self.vec = TfidfVectorizer()
        self.matrix = self.vec.fit_transform([preprocess(f["q"]) for f in self.faqs])

    def reply(self, question: str) -> str:
        v = self.vec.transform([preprocess(question)])
        sims = cosine_similarity(v, self.matrix)[0]
        best = sims.argmax()
        if sims[best] < self.threshold:
            return "Sorry, I couldn't find an answer. Please try rephrasing."
        return self.faqs[best]["a"]

if __name__ == "__main__":
    bot = FAQBot()
    print("FAQ Chatbot (type 'quit' to exit)")
    while True:
        q = input("You: ").strip()
        if q.lower() in {"quit", "exit"}:
            break
        print("Bot:", bot.reply(q))
